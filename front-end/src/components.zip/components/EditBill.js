import React, { Component } from 'react';
import axios from 'axios';
import autobind from 'react-autobind';
import {Button, Form, Header, Grid, Segment, Message, Image, Input, Dropdown, Menu} from 'semantic-ui-react';
import NavigationBar from './NavigationBar';
import Footer from './Footer';

class EditBill extends Component {
    constructor(props){
        super(props);
        autobind(this);

        this.state={
            bill_number : '',
            bill_name: '',
            status: '',
            legal_history: '',
            showWhatToEdit: false,
            edited: false
        }
    }
    handleInputBillNumberChange(e){
        this.setState({
            bill_number: e.target.value,
            edited: false
        });
    }
    handleInputBillNameChange(e){
        this.setState({
            bill_name: e.target.value,
            edited: false
        });
    }
    handleInputStatusChange(e){
        this.setState({
            status: e.target.value,
            edited: false
        });
    }
    handleInputLegalHistoryChange(e){
        this.setState({
            legal_history: e.target.value,
            edited: false
        });
    }
    whatToEdit(){
        return(
            <div>
                <NavigationBar/>
                <Segment
                inverted
                textAlign='center'
                color='yellow'
                style={{ minHeight: 650, padding: '0em 0em' }}
                vertical
                >

            <Grid textAlign='center' style={{height:'100%',padding:'5em'}} verticalAlign='middle' >
            <Grid.Column style={{maxWidth: 450}}>
                <Header inverted as='h2' textAlign='center'>BILL TO UPDATE</Header>
                <Form size='large'>
                <Segment stacked>

                    <input type="text" placeholder="New Bill Name" onChange={this.handleInputBillNameChange}/>
                    <br /><br/>
                    <input type="text" placeholder="New Bill Status" onChange={this.handleInputStatusChange}/>
                    <br /><br/>
                    <input type="text" placeholder="New Bill Legal History" onChange={this.handleInputLegalHistoryChange}/>
                    <br /><br/>
                <Button color='black' fluid onClick={this.handleEdit}>Submit</Button>
                </Segment>
                 </Form>

                 </Grid.Column>
            </Grid>
            </Segment>             
            </div>
        )
    }
    showWhatToEditChange(e){
        this.setState({
            showWhatToEdit: true
        })
    }
    handleEdit(e){
        
        this.editBill();
    }
 
    editBill(){
        axios.post('http://localhost:3001/edit-bill',{
            headers:{
				'Content-Type': 'application/json'				
			},
            data: {
                bill_number : this.state.bill_number,
                bill_name: this.state.bill_name,
                status: this.state.status,
                legal_history: this.state.legal_history
            }
        })
        .then(function (response) {
            console.log(response.data);
            
        })
        .catch(err => {
            console.error(err);
        });
        this.setState({
            edited: true
        });
    }
    render(){
        let shouldDisplayEdit = null;
        if(this.state.showWhatToEdit){
            shouldDisplayEdit = this.whatToEdit();
        }
        return(
            <div>
                <NavigationBar/>
                <Segment
                inverted
                textAlign='center'
                color='yellow'
                style={{ minHeight: 650, padding: '0em 0em' }}
                vertical
                >
                    <Grid textAlign='center' style={{height:'100%',padding:'5em'}} verticalAlign='middle' >
                        <Grid.Column style={{maxWidth: 450}}>
                            <Header inverted as='h2' textAlign='center'>NEW BILL</Header>
                            <Form size='large'>
                                <Segment stacked>
                                <input type="text" name="inputbillnum" placeholder="Bill Number" className="input" onChange={this.handleInputBillNumberChange} />
                                <br /><br/>
                                
                                <Button color='black' fluid onClick={this.showWhatToEditChange}>EDIT</Button>
                                </Segment>
                            </Form>
                            <label id="success-message">
                                {
                                this.state.edited ? 'Bill Successfully Edited!' : ''
                                }
                            </label>
                        </Grid.Column>
                    </Grid>
                {shouldDisplayEdit}
                </Segment> 
                <Footer/>               
            </div>
        )
    }
}
export default EditBill;